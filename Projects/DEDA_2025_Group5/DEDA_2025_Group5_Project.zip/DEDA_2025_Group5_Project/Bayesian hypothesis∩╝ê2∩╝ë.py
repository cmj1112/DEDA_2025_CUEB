# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:43:27 2024

@author: 14421
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder

# 数据加载
file_path = r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv"
data = pd.read_csv(file_path)

# 数据检查与清理
print("数据类型检查:")
print(data.dtypes)

# 假设“Gender”列为字符串类型，需要进行编码
label_columns = data.select_dtypes(include=[object]).columns
encoder = LabelEncoder()

for column in label_columns:
    data[column] = encoder.fit_transform(data[column])

# 查看数据清理后的结果
print("\n数据清理后的数据类型:")
print(data.dtypes)

# 选择特性和标签
X = data.drop(columns=['Exited'])  # 假设“Exited”是标签列
y = data['Exited']

# 数据分割，80%训练，20%测试
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 训练朴素贝叶斯分类器
model = GaussianNB()
model.fit(X_train, y_train)

# 预测
y_pred = model.predict(X_test)

# 评估模型
accuracy = accuracy_score(y_test, y_pred)
print(f"朴素贝叶斯分类器的准确率: {accuracy:.4f}")

