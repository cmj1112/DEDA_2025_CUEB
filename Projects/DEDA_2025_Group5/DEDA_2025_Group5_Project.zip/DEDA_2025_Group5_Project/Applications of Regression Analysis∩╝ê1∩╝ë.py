# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:09:40 2024

@author: 14421
"""

# 导入pandas库用于数据处理
import pandas as pd
# 导入numpy库用于数值计算
import numpy as np
# 导入sklearn的model_selection模块用于数据分割
from sklearn.model_selection import train_test_split
# 导入sklearn的linear_model模块用于线性回归
from sklearn.linear_model import LinearRegression
# 导入sklearn的metrics模块用于模型评估
from sklearn.metrics import mean_squared_error, r2_score
# 导入matplotlib.pyplot库用于绘制图表
import matplotlib.pyplot as plt

# 设置文件路径并加载数据到DataFrame对象
file_path = r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv"
df = pd.read_csv(file_path)

# 打印数据的基本信息
print("数据概览：")
print(df.info())
# 打印数值型数据的统计信息
print("\n数值型数据统计：")
print(df.describe())

# 选择特征变量和目标变量
features = ['CreditScore', 'Age', 'Tenure', 'Balance', 'NumOfProducts', 'EstimatedSalary']
target = 'Exited'  # 客户是否流失
X = df[features]  # 特征变量
y = df[target]    # 目标变量

# 使用train_test_split函数划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 创建线性回归模型实例并拟合训练数据
model = LinearRegression()
model.fit(X_train, y_train)

# 使用训练好的模型进行预测
y_pred = model.predict(X_test)

# 计算预测结果的均方误差和决定系数
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

# 打印模型评估结果
print("\n模型评估：")
print(f"均方误差 (MSE)：{mse:.2f}")
print(f"决定系数 (R^2)：{r2:.2f}")

# 绘制实际值与预测值的散点图
plt.figure(figsize=(8, 6))
plt.scatter(y_test, y_pred, alpha=0.5)
plt.xlabel('Actual Values')  # 设置x轴标签
plt.ylabel('Predicted Values')  # 设置y轴标签
plt.title('Linear Regression Prediction Results')  # 设置图表标题
plt.grid(True)  # 显示网格
plt.show()  # 显示图表
