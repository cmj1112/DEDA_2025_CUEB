# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:42:42 2024

@author: 14421
"""
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import LabelEncoder

# 加载数据
file_path = r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv"
df = pd.read_csv(file_path)

# 查看数据的一些基本信息
print("数据的基本信息:")
print(df.info())  # 输出数据的列名、数据类型和缺失值情况

# 检查数据的前几行，确认是否存在非数值型特征
print("\n数据的前几行:")
print(df.head())

# 数据清洗 - 填充缺失值
# 对于数值型列使用均值填充，类别型列使用众数填充
for column in df.select_dtypes(include=['float64', 'int64']).columns:
    df[column].fillna(df[column].mean(), inplace=True)

for column in df.select_dtypes(include='object').columns:
    df[column].fillna(df[column].mode()[0], inplace=True)

# 检查是否还存在缺失值
print("\n缺失值检查:")
print(df.isnull().sum())

# 如果有非数值型列，进行标签编码
label_encoder = LabelEncoder()
categorical_columns = df.select_dtypes(include=['object']).columns
for column in categorical_columns:
    df[column] = label_encoder.fit_transform(df[column])

# 选择特征和目标变量
# 这里假设目标变量为 'Exited'，特征为其它列
X = df.drop('Exited', axis=1)  # 选择所有非目标变量的特征
y = df['Exited']  # 目标变量

# 数据集划分：80%训练集，20%测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 初始化并训练高斯朴素贝叶斯分类器
model = GaussianNB()
model.fit(X_train, y_train)

# 预测
y_pred = model.predict(X_test)

# 计算模型准确率
accuracy = accuracy_score(y_test, y_pred)
print(f'\n模型准确率：{accuracy * 100:.2f}%')

# 输出混淆矩阵
print('\n混淆矩阵：')
print(confusion_matrix(y_test, y_pred))
