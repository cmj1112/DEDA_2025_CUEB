# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:29:58 2024

@author: 14421
"""

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

# 读取数据
data = pd.read_csv(r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv")

# 查看数据类型
print("数据类型：")
print(data.dtypes)

# 选择包含非数值数据的列
non_numeric_columns = data.select_dtypes(include=['object']).columns
print("\n非数值列：", non_numeric_columns)

# 对非数值列，使用LabelEncoder进行编码
label_encoder = LabelEncoder()

for column in non_numeric_columns:
    data[column] = label_encoder.fit_transform(data[column])

# 检查是否存在缺失值并处理
print("\n检查缺失值：")
print(data.isnull().sum())

# 用均值填充数值列中的缺失值
data.fillna(data.mean(), inplace=True)

# 查看处理后的数据
print("\n处理后的数据：")
print(data.head())

# 假设目标列是 'Exited'
X = data.drop(columns=['Exited'])
y = data['Exited']

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 初始化基础学习器（决策树）
base_model = DecisionTreeClassifier(max_depth=1)

# 初始化 AdaBoost 模型
ada_model = AdaBoostClassifier(estimator=base_model, n_estimators=50, random_state=42)

# 训练模型
ada_model.fit(X_train, y_train)

# 预测
y_pred = ada_model.predict(X_test)

# 评估准确性
accuracy = accuracy_score(y_test, y_pred)

print(f'\nAdaBoost模型的准确率：{accuracy:.4f}')
