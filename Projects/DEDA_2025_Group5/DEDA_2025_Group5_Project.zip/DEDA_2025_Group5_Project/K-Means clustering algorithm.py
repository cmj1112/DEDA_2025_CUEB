# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:40:11 2024

@author: 14421
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score  # 导入 silhouette_score 函数

# 加载数据
data = pd.read_csv(r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv")

# 查看数据的几行
print(data.head())

# 选择需要进行聚类的特征，假设我们选择 'Age', 'Balance', 'NumOfProducts' 等
features = data[['Age', 'Balance', 'NumOfProducts']]

# 处理缺失值（如果有）
features = features.dropna()

# 数据标准化
scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# 使用肘部法选择K值
inertia = []

for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(features_scaled)
    inertia.append(kmeans.inertia_)

# 绘制肘部法图表
plt.plot(range(1, 11), inertia)
plt.title('Elbow Method for Optimal K')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Inertia')
plt.show()

# 执行K-means聚类
kmeans = KMeans(n_clusters=3, random_state=42)
data['Cluster'] = kmeans.fit_predict(features_scaled)

# 打印聚类结果
print(data[['Age', 'Balance', 'NumOfProducts', 'Cluster']].head())

# 计算并打印轮廓分数
sil_score = silhouette_score(features_scaled, data['Cluster'])
print(f'Silhouette Score: {sil_score}')
