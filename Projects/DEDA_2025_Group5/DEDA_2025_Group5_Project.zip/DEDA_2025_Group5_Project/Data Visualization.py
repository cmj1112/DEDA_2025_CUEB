# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:05:52 2024

@author: 14421
"""

# 导入pandas库用于数据处理
import pandas as pd
# 导入matplotlib.pyplot库用于绘制图表
import matplotlib.pyplot as plt
# 导入seaborn库用于绘制更美观的统计图表
import seaborn as sns

# 设置文件路径并加载数据到DataFrame对象
file_path = r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv"
df = pd.read_csv(file_path)

# 创建一个图形，设置大小为10x6英寸
plt.figure(figsize=(10, 6))
# 使用seaborn的countplot绘制按地理分布的客户数量条形图
sns.countplot(x='Geography', data=df, palette="pastel")
# 设置图形标题和字体大小
plt.title(label="Customer Distribution by Geography", fontsize=16)
# 设置x轴标签和字体大小
plt.xlabel(xlabel="Country", fontsize=12)
# 设置y轴标签和字体大小
plt.ylabel(ylabel="Number of Customers", fontsize=12)
# 显示图形
plt.show()

# 创建一个图形，设置大小为10x6英寸
plt.figure(figsize=(10, 6))

# 使用seaborn的kdeplot绘制未流失客户的余额密度图
sns.kdeplot(data=df[df['Exited'] == 0]['Balance'], label="Not Churned", fill=True, alpha=0.5, color="green")
# 使用seaborn的kdeplot绘制已流失客户的余额密度图
sns.kdeplot(data=df[df['Exited'] == 1]['Balance'], label="Churned", fill=True, alpha=0.5, color="red")

# 设置图形标题和字体大小
plt.title(label="Customer Balance Distribution (Churned vs Not Churned)", fontsize=16)
# 设置x轴标签和字体大小
plt.xlabel(xlabel="Balance", fontsize=12)
# 设置y轴标签和字体大小
plt.ylabel(ylabel="Density", fontsize=12)
# 显示图例
plt.legend()

# 显示图形
plt.show()

# 设置seaborn的绘图风格为whitegrid
sns.set(style="whitegrid")
# 创建一个图形，设置大小为10x6英寸
plt.figure(figsize=(10, 6))
# 使用seaborn的histplot绘制客户年龄分布图，包括密度曲线
sns.histplot(df['Age'], kde=True, bins=30, color='skyblue')
# 设置图形标题和字体大小
plt.title(label="Customer Age Distribution", fontsize=16)
# 设置x轴标签和字体大小
plt.xlabel(xlabel="Age", fontsize=12)
# 设置y轴标签和字体大小
plt.ylabel(ylabel="Frequency", fontsize=12)
# 显示图形
plt.show()
