# -*- coding: utf-8 -*-
"""
Created on Mon Dec 23 20:03:06 2024

@author: 14421
"""

# 导入pandas库用于数据处理
import pandas as pd

# 定义文件路径
file_path=r"C:\Users\14421\Desktop\银行客户流失\代码及数据\Churn_Modelling.csv"

# 使用pandas的read_csv函数加载数据到DataFrame对象
df = pd.read_csv(file_path)

# 打印数据的行列数
print("数据的行列数:", df.shape)

# 打印数据类型和缺失值情况
print("\n数据类型和缺失值情况:")
print(df.info())

# 打印数据的前几行
print(df.head())
